#Data Preprocessing
Create classes of all demographics, AAE and SAE. Each class contains train, dev, test, unlabled set and the length of each Tweet.

#Machine Learning Models
 ## KNN - Baseline 
 Create the knn model, which will return the prediction

 ##Gaussian Naive Bayes
 Create the GNB model, which will return the prediction

 ##Logistic Regression
 Create the LR model, which will return the prediction

#Evaluation
 Evaluate each model's performance of the 2 demographics and tfidf and emb dataset

 ##LR Evaluation
 Return the plots of the range of probability of prediction accuracies and number of the range of prediction confidence

#POS Tagging
Create a function that tag Tweets' POS

 #Mutual Information Classification
 Evaluate the MIC of each POS and the accuracies of each model using POS feature set